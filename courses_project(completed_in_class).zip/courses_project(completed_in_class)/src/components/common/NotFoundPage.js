import React from "react"

const NotFoundPage = () => (
    <div className="container mt-5">
        <h1 className="center">Page not found</h1>
    </div>
)

export default NotFoundPage
